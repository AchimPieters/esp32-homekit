## [3.0.1] - 2026-07-29

### Fixed
- Set `SO_SNDTIMEO` on accepted client sockets. `homekit_server_process_notifications()` holds `server->notification_lock` across its whole client loop, including the blocking `write()` calls; a client that vanished without closing its TCP connection could block that write indefinitely, freezing every `homekit_characteristic_notify()` call from application code until the stale connection was reaped.

## [2.0.3] - 2026-02-20

### Added
- minor fixes

## [2.0.1] - 2026-02-20

### Added
- Updated wolfssl to 5.8.2~1 and espressif/mdns to 1.9.1
- minor fixes

### Removed
- Removed outdated and incorrect information.

## [1.2.5] - 2025-06-11

### Added
- Updated wolfssl to 5.8.0 and espressif/mdns to 1.8.2
- Fix base64 decoded size calculation for short inputs

### Removed
- Removed outdated and incorrect information.

## [1.2.4] - 2025-03-13

### Added
- Updated `README.md` file of the LED example.
- Added `homekit_led.png` as an illustration for the LED example.
- Updated the general `README.md` file.

### Removed
- Removed outdated and incorrect information.

## [1.2.0] - 2025-03-12

### Added
- Added `CHANGELOG.md` as Changelog.
- All notable changes to this project will be documented in this file.
- The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project follows [Semantic Versioning](https://semver.org/).
